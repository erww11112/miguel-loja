"use client";
import React from "react";
import { ShoppingCart } from "lucide-react";

const products = [
  { id: 1, name: "Camiseta Básica", price: "R$ 49,90", image: "/images/camiseta.jpg" },
  { id: 2, name: "Calça Jeans", price: "R$ 129,90", image: "/images/calca.jpg" },
  { id: 3, name: "Jaqueta Casual", price: "R$ 199,90", image: "/images/jaqueta.jpg" },
  { id: 4, name: "Tênis Esportivo", price: "R$ 249,90", image: "/images/tenis.jpg" },
];

export default function Loja() {
  return (
    <div className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {products.map((product) => (
        <div key={product.id} className="bg-white p-4 shadow-lg rounded-xl">
          <img src={product.image} alt={product.name} className="w-full h-48 object-cover rounded-lg" />
          <div className="text-center mt-4">
            <h3 className="text-lg font-semibold">{product.name}</h3>
            <p className="text-gray-500">{product.price}</p>
            <button className="mt-2 w-full flex items-center justify-center gap-2 bg-black text-white py-2 px-4 rounded-md hover:bg-gray-800">
              <ShoppingCart size={16} /> Comprar
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
